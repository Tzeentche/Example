package com.github.vitalliuss.helloci;

/**
 * Hello CI!
 *
 */
public class App 
{
    public static void main( String[] args )
    {
        System.out.println( "Hello CI!" );
    }
    
    public static void doNothing() {
    	// do nothing
    }
}
