﻿namespace Calculator
{

    public class Calc
    {
        public static int Sum(int a, int b)
        {
            return a + b;
        }

        public static int Substract(int a, int b)
        {
            return a - b;
        }
        
        public static int Multiply(int a, int b)
        {
            return a * b;
        }
        
        public static int Devide(int a, int b)
        {
            return a / b;
        }
    }
}
